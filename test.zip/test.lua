print "Hello"
